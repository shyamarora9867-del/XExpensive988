import { db } from "./db";
import {
  expenses,
  type InsertExpense,
  type Expense
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  getExpenses(): Promise<Expense[]>;
  getExpense(id: number): Promise<Expense | undefined>;
  createExpense(expense: InsertExpense): Promise<Expense>;
  deleteExpense(id: number): Promise<void>;
  deleteAllExpenses(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getExpenses(): Promise<Expense[]> {
    return await db.select().from(expenses).orderBy(desc(expenses.date));
  }

  async getExpense(id: number): Promise<Expense | undefined> {
    const [expense] = await db.select().from(expenses).where(eq(expenses.id, id));
    return expense;
  }

  async createExpense(insertExpense: InsertExpense): Promise<Expense> {
    const [expense] = await db.insert(expenses).values(insertExpense).returning();
    return expense;
  }

  async deleteExpense(id: number): Promise<void> {
    await db.delete(expenses).where(eq(expenses.id, id));
  }

  async deleteAllExpenses(): Promise<void> {
    await db.delete(expenses);
  }
}

export const storage = new DatabaseStorage();
