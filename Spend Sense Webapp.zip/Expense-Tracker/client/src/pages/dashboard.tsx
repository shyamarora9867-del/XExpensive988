import { useState } from "react";
import { useExpenses, useDeleteAllExpenses } from "@/hooks/use-expenses";
import { ExpenseForm } from "@/components/expense-form";
import { ExpenseChart } from "@/components/expense-chart";
import { ExpenseList } from "@/components/expense-list";
import { useToast } from "@/hooks/use-toast";
import { Wallet, TrendingDown, LayoutDashboard, Loader2, Trash2, AlertTriangle } from "lucide-react";

export default function Dashboard() {
  const { data: expenses, isLoading, error } = useExpenses();
  const deleteAllMutation = useDeleteAllExpenses();
  const { toast } = useToast();
  const [showConfirm, setShowConfirm] = useState(false);

  const handleDeleteAll = () => {
    deleteAllMutation.mutate(undefined, {
      onSuccess: () => {
        setShowConfirm(false);
        toast({ title: "All expenses deleted", description: "Your expense history has been cleared." });
      },
      onError: () => {
        toast({ title: "Error", description: "Failed to delete expenses.", variant: "destructive" });
      },
    });
  };

  // Calculate top-level metrics
  const totalSpend = expenses 
    ? expenses.reduce((sum, e) => sum + e.amount, 0) / 100 
    : 0;

  const highestExpense = expenses && expenses.length > 0
    ? expenses.reduce((max, e) => e.amount > max.amount ? e : max, expenses[0])
    : null;

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center text-destructive">
        <p className="text-lg">Failed to load data: {(error as Error).message}</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-8 pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      
      {/* Header */}
      <header className="mb-10 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-primary/20 text-primary rounded-xl flex items-center justify-center">
            <LayoutDashboard className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-foreground">Overview</h1>
            <p className="text-muted-foreground">Track and manage your expenses seamlessly.</p>
          </div>
        </div>
      </header>

      {isLoading ? (
        <div className="flex items-center justify-center h-64">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Main Content (Left side on desktop) */}
          <div className="lg:col-span-8 space-y-8">
            
            {/* KPI Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="glass-panel p-6 rounded-2xl relative overflow-hidden group">
                <div className="absolute top-0 right-0 p-6 opacity-20 group-hover:opacity-30 group-hover:scale-110 transition-all duration-500">
                  <Wallet className="w-24 h-24 text-primary" />
                </div>
                <h3 className="text-muted-foreground font-medium mb-2">Total Spend</h3>
                <div className="text-4xl font-bold text-foreground tracking-tight">
                  ₹{totalSpend.toFixed(2)}
                </div>
                <div className="mt-2 text-sm text-primary flex items-center gap-1">
                  All recorded transactions
                </div>
              </div>

              <div className="glass-panel p-6 rounded-2xl relative overflow-hidden group">
                <div className="absolute top-0 right-0 p-6 opacity-20 group-hover:opacity-30 group-hover:scale-110 transition-all duration-500">
                  <TrendingDown className="w-24 h-24 text-destructive" />
                </div>
                <h3 className="text-muted-foreground font-medium mb-2">Largest Expense</h3>
                <div className="text-4xl font-bold text-foreground tracking-tight truncate">
                  {highestExpense ? `₹${(highestExpense.amount / 100).toFixed(2)}` : '₹0.00'}
                </div>
                <div className="mt-2 text-sm text-muted-foreground flex items-center gap-1 truncate">
                  {highestExpense ? highestExpense.title : 'No data'}
                </div>
              </div>
            </div>

            {/* Chart Section */}
            <div className="glass-panel p-6 rounded-2xl">
              <div className="mb-4">
                <h2 className="text-xl font-bold text-foreground">Spending by Category</h2>
                <p className="text-sm text-muted-foreground">Distribution of your expenses</p>
              </div>
              <ExpenseChart expenses={expenses || []} />
            </div>

            {/* Recent Expenses List */}
            <div className="glass-panel p-6 rounded-2xl">
              <div className="mb-6 flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-foreground">Recent Transactions</h2>
                  <p className="text-sm text-muted-foreground">Your latest recorded expenses</p>
                </div>
                {expenses && expenses.length > 0 && (
                  <button
                    data-testid="button-delete-all"
                    onClick={() => setShowConfirm(true)}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium text-destructive border border-destructive/30 hover:bg-destructive/10 transition-all duration-200"
                  >
                    <Trash2 className="w-4 h-4" />
                    Delete All
                  </button>
                )}
              </div>
              <ExpenseList expenses={expenses || []} />
            </div>
          </div>

          {/* Confirmation Modal */}
          {showConfirm && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
              <div className="glass-panel rounded-2xl p-6 w-full max-w-sm border border-white/10 shadow-2xl">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-xl bg-destructive/10 flex items-center justify-center text-destructive">
                    <AlertTriangle className="w-5 h-5" />
                  </div>
                  <h3 className="text-lg font-bold text-foreground">Delete All Expenses?</h3>
                </div>
                <p className="text-muted-foreground text-sm mb-6">
                  This will permanently delete all your recorded expenses. This action cannot be undone.
                </p>
                <div className="flex gap-3">
                  <button
                    data-testid="button-cancel-delete-all"
                    onClick={() => setShowConfirm(false)}
                    disabled={deleteAllMutation.isPending}
                    className="flex-1 py-2.5 px-4 rounded-xl border border-white/10 text-sm font-medium text-muted-foreground hover:bg-white/5 transition-all disabled:opacity-50"
                  >
                    Cancel
                  </button>
                  <button
                    data-testid="button-confirm-delete-all"
                    onClick={handleDeleteAll}
                    disabled={deleteAllMutation.isPending}
                    className="flex-1 py-2.5 px-4 rounded-xl bg-destructive text-white text-sm font-medium hover:bg-destructive/90 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {deleteAllMutation.isPending ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <>
                        <Trash2 className="w-4 h-4" />
                        Delete All
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Sidebar (Right side on desktop) */}
          <div className="lg:col-span-4">
            <div className="sticky top-8">
              <ExpenseForm />
            </div>
          </div>

        </div>
      )}
    </div>
  );
}
