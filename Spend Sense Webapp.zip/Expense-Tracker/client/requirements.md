## Packages
recharts | Beautiful charting library for the monthly spending chart
date-fns | Date formatting and manipulation for expenses
lucide-react | Beautiful icons for the UI
next-themes | Dark mode support
react-hook-form | Form state management
@hookform/resolvers | Zod resolver for forms

## Notes
- Using Recharts for data visualization.
- Amount is stored in cents in the database, UI converts to dollars for display and input.
- Added custom styling with glassmorphism to match the "Dark Mode Professional" aesthetic.
- Relies on `@shared/routes` and `@shared/schema` for API contracts and types.
