import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Plus, Loader2 } from "lucide-react";
import { useCreateExpense } from "@/hooks/use-expenses";
import { useToast } from "@/hooks/use-toast";

const categories = [
  "Food & Dining",
  "Transportation",
  "Utilities",
  "Entertainment",
  "Shopping",
  "Health",
  "Other"
];

const formSchema = z.object({
  title: z.string().min(1, "Title is required").max(50, "Title is too long"),
  amount: z.coerce.number().min(0.01, "Amount must be greater than 0"),
  category: z.string().min(1, "Category is required"),
  date: z.coerce.date(),
});

type FormData = z.infer<typeof formSchema>;

export function ExpenseForm() {
  const { toast } = useToast();
  const createMutation = useCreateExpense();
  
  const { register, handleSubmit, reset, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      amount: undefined,
      category: "Food & Dining",
      date: new Date(),
    }
  });

  const onSubmit = (data: FormData) => {
    // Convert dollars to cents for the database
    const amountInCents = Math.round(data.amount * 100);
    
    createMutation.mutate({
      title: data.title,
      amount: amountInCents,
      category: data.category,
      date: data.date,
    }, {
      onSuccess: () => {
        toast({
          title: "Expense added",
          description: `Successfully added ${data.title}`,
        });
        reset({
          title: "",
          amount: undefined as any,
          category: data.category,
          date: new Date(),
        });
      },
      onError: (err) => {
        toast({
          title: "Error",
          description: err.message,
          variant: "destructive",
        });
      }
    });
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="glass-panel p-6 sm:p-8 rounded-2xl flex flex-col gap-5 relative overflow-hidden group">
      {/* Decorative background glow */}
      <div className="absolute top-0 right-0 -mr-16 -mt-16 w-32 h-32 bg-primary/20 blur-3xl rounded-full pointer-events-none group-hover:bg-primary/30 transition-colors duration-500" />

      <div>
        <h2 className="text-2xl font-bold text-foreground">Add Expense</h2>
        <p className="text-muted-foreground text-sm mt-1">Track a new transaction</p>
      </div>

      <div className="space-y-4">
        <div>
          <label className="text-sm font-medium text-foreground mb-1.5 block">Title</label>
          <input 
            {...register("title")} 
            className="glass-input" 
            placeholder="e.g., Morning Coffee"
          />
          {errors.title && <span className="text-destructive text-xs mt-1 block">{errors.title.message}</span>}
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-sm font-medium text-foreground mb-1.5 block">Amount (₹)</label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground">₹</span>
              <input 
                type="number" 
                step="0.01"
                {...register("amount")} 
                className="glass-input pl-8" 
                placeholder="0.00"
              />
            </div>
            {errors.amount && <span className="text-destructive text-xs mt-1 block">{errors.amount.message}</span>}
          </div>

          <div>
            <label className="text-sm font-medium text-foreground mb-1.5 block">Date</label>
            <input 
              type="date" 
              {...register("date")} 
              className="glass-input" 
              style={{ colorScheme: 'dark' }}
            />
            {errors.date && <span className="text-destructive text-xs mt-1 block">{errors.date.message}</span>}
          </div>
        </div>

        <div>
          <label className="text-sm font-medium text-foreground mb-1.5 block">Category</label>
          <select {...register("category")} className="glass-input appearance-none">
            {categories.map(c => (
              <option key={c} value={c} className="bg-card text-foreground">{c}</option>
            ))}
          </select>
          {errors.category && <span className="text-destructive text-xs mt-1 block">{errors.category.message}</span>}
        </div>
      </div>

      <button
        type="submit"
        disabled={createMutation.isPending}
        className="mt-2 w-full py-3.5 px-4 rounded-xl font-semibold flex items-center justify-center gap-2
          bg-primary text-primary-foreground shadow-lg shadow-primary/25
          hover:shadow-primary/40 hover:-translate-y-0.5 hover:bg-primary/90
          active:translate-y-0 active:shadow-md
          disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none
          transition-all duration-200 ease-out"
      >
        {createMutation.isPending ? (
          <Loader2 className="w-5 h-5 animate-spin" />
        ) : (
          <>
            <Plus className="w-5 h-5" />
            Add Transaction
          </>
        )}
      </button>
    </form>
  );
}
