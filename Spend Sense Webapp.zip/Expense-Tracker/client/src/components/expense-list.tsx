import { format } from "date-fns";
import { Trash2, ShoppingBag, Utensils, Car, Zap, Heart, Coffee, CreditCard } from "lucide-react";
import { useDeleteExpense } from "@/hooks/use-expenses";
import { useToast } from "@/hooks/use-toast";

interface Expense {
  id: number;
  title: string;
  amount: number;
  category: string;
  date: string | Date;
}

interface ExpenseListProps {
  expenses: Expense[];
}

const getCategoryIcon = (category: string) => {
  switch (category) {
    case "Food & Dining": return <Utensils className="w-5 h-5" />;
    case "Transportation": return <Car className="w-5 h-5" />;
    case "Utilities": return <Zap className="w-5 h-5" />;
    case "Entertainment": return <Coffee className="w-5 h-5" />;
    case "Shopping": return <ShoppingBag className="w-5 h-5" />;
    case "Health": return <Heart className="w-5 h-5" />;
    default: return <CreditCard className="w-5 h-5" />;
  }
};

export function ExpenseList({ expenses }: ExpenseListProps) {
  const deleteMutation = useDeleteExpense();
  const { toast } = useToast();

  const handleDelete = (id: number, title: string) => {
    deleteMutation.mutate(id, {
      onSuccess: () => {
        toast({
          title: "Expense deleted",
          description: `${title} was removed successfully.`,
        });
      },
      onError: () => {
        toast({
          title: "Error",
          description: "Failed to delete the expense.",
          variant: "destructive",
        });
      }
    });
  };

  if (expenses.length === 0) {
    return (
      <div className="py-12 text-center">
        <div className="w-16 h-16 mx-auto bg-white/5 rounded-full flex items-center justify-center mb-4">
          <CreditCard className="w-8 h-8 text-muted-foreground" />
        </div>
        <h3 className="text-lg font-medium text-foreground">No expenses yet</h3>
        <p className="text-muted-foreground mt-1">Add your first transaction above to get started.</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {expenses.map((expense) => {
        const dateObj = new Date(expense.date);
        const dollars = (expense.amount / 100).toFixed(2);
        const isDeleting = deleteMutation.isPending && deleteMutation.variables === expense.id;

        return (
          <div 
            key={expense.id} 
            className="group flex items-center justify-between p-4 rounded-2xl bg-white/[0.02] border border-white/[0.05] hover:bg-white/[0.04] hover:border-white/[0.1] transition-all duration-300"
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-primary/10 text-primary flex items-center justify-center">
                {getCategoryIcon(expense.category)}
              </div>
              <div>
                <h4 className="font-semibold text-foreground">{expense.title}</h4>
                <div className="flex items-center gap-2 text-sm text-muted-foreground mt-0.5">
                  <span>{expense.category}</span>
                  <span className="w-1 h-1 rounded-full bg-white/20" />
                  <span>{format(dateObj, 'MMM d, yyyy')}</span>
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <span className="font-bold text-lg text-foreground">₹{dollars}</span>
              <button
                onClick={() => handleDelete(expense.id, expense.title)}
                disabled={isDeleting}
                className="w-8 h-8 rounded-full flex items-center justify-center text-muted-foreground hover:text-destructive hover:bg-destructive/10 opacity-0 group-hover:opacity-100 transition-all disabled:opacity-50"
                title="Delete expense"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
}
