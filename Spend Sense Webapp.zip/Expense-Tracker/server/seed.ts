import { storage } from "./storage";

async function seedDatabase() {
  const existingItems = await storage.getExpenses();
  if (existingItems.length === 0) {
    await storage.createExpense({ title: "Groceries", amount: 12550, category: "Food" });
    await storage.createExpense({ title: "Internet Bill", amount: 8000, category: "Utilities" });
    await storage.createExpense({ title: "Gas Station", amount: 4500, category: "Transportation" });
    await storage.createExpense({ title: "Movie Tickets", amount: 3200, category: "Entertainment" });
    await storage.createExpense({ title: "Coffee Shop", amount: 550, category: "Food" });
    console.log("Database seeded successfully");
  } else {
    console.log("Database already has data, skipping seed");
  }
  process.exit(0);
}

seedDatabase().catch((e) => {
  console.error("Failed to seed database:", e);
  process.exit(1);
});
